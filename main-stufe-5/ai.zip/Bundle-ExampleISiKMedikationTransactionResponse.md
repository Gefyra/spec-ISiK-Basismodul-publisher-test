# ExampleISiKMedikationTransactionResponse - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ExampleISiKMedikationTransactionResponse**

## Example Bundle: ExampleISiKMedikationTransactionResponse

Profile: [ISiK Medikation TransactionBundle-Response](StructureDefinition-ISiKMedikationTransactionResponse.md)

Bundle ExampleISiKMedikationTransactionResponse of type transaction-response

-------

Entry 1 - fullUrl = http://my.target.fhir.server.local/MedicationStatement/ExampleISiKMedikationsInformation1

Resource MedicationStatement:

> 

Profile: [ISiKMedikationsInformation](StructureDefinition-ISiKMedikationsInformation.md)

**ISiK Accepted Risk**: Erhöhtes Blutungsrisiko ist in diesem Fall vertretbar.**ISiK Medikationsart**:[ISiK Medikationsart: akut](CodeSystem-ISiKMedikationsartCS.md#ISiKMedikationsartCS-akut)(Akutmedikation)**ISiK Selbstmedikation**: true**ISiK Behandlungsziel**: Schmerztherapie postoperativ**status**: active**status**: recorded**subject**:[Erika Fürstin von Musterfrau (official) Female, DoB: 1964-08-12 ( Private Krankenversicherung (use: secondary, ))](Patient-PatientinMusterfrau.md)**effective**: 2021-07-01 --> (ongoing)**dateAsserted**: 2021-07-01
> **dosage****timing**: Morning, Noon, Evening, Once

### DoseAndRates

| | |
| :--- | :--- |
| - | **Dose[x]** |
| * | 1 Brausetablette(Details: UCUM code1 = '1') |



Response:

```
201
Location = http://my.fhir.server.local/MedicationStatement/ExampleISiKMedikationsInformation1

```

-------

Entry 2 - fullUrl = http://my.target.fhir.server.local/Medication/ExampleISiKMedikament1

Resource Medication:

> Medikament codiert (Wirkstoff)

Response:

```
201
Location = http://my.fhir.server.local/Medication/ExampleISiKMedikament1

```



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "ExampleISiKMedikationTransactionResponse",
  "meta" : {
    "profile" : [
      "http://gefyra.info/training/StructureDefinition/ISiKMedikationTransactionResponse"
    ]
  },
  "type" : "transaction-response",
  "entry" : [
    {
      "fullUrl" : "http://my.target.fhir.server.local/MedicationStatement/ExampleISiKMedikationsInformation1",
      "resource" : {
        "resourceType" : "MedicationStatement",
        "id" : "ExampleISiKMedikationsInformation1",
        "meta" : {
          "profile" : [
            "http://gefyra.info/training/StructureDefinition/ISiKMedikationsInformation"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MedicationStatement_ExampleISiKMedikationsInformation1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MedicationStatement ExampleISiKMedikationsInformation1</b></p><a name=\"ExampleISiKMedikationsInformation1\"> </a><a name=\"hcExampleISiKMedikationsInformation1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ISiKMedikationsInformation.html\">ISiKMedikationsInformation</a></p></div><p><b>ISiK Accepted Risk</b>: Erhöhtes Blutungsrisiko ist in diesem Fall vertretbar.</p><p><b>ISiK Medikationsart</b>: <a href=\"CodeSystem-ISiKMedikationsartCS.html#ISiKMedikationsartCS-akut\">ISiK Medikationsart: akut</a> (Akutmedikation)</p><p><b>ISiK Selbstmedikation</b>: true</p><p><b>ISiK Behandlungsziel</b>: Schmerztherapie postoperativ</p><p><b>status</b>: Active</p><p><b>medication</b>: <a href=\"Medication-ExampleISiKMedikament1.html\">Medication Acetylcystein</a></p><p><b>subject</b>: <a href=\"Patient-PatientinMusterfrau.html\">Erika Fürstin von Musterfrau (official) Female, DoB: 1964-08-12 ( Private Krankenversicherung (use: secondary, ))</a></p><p><b>context</b>: <a href=\"Encounter-FachabteilungskontaktMinimal.html\">Encounter: identifier = Visit number; status = unknown; class = inpatient encounter (ActCode#IMP); type = Operation,Abteilungskontakt; serviceType = Innere Medizin; period = 2022-05-03 --&gt; 2022-05-05</a></p><p><b>effective</b>: 2021-07-01 --&gt; (ongoing)</p><p><b>dateAsserted</b>: 2021-07-01</p><p><b>reasonReference</b>: <a href=\"Condition-BehandlungsDiagnoseFreitext.html\">Condition </a></p><blockquote><p><b>dosage</b></p><p><b>timing</b>: Morning, Noon, Evening, Once</p><h3>DoseAndRates</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Dose[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>1 Brausetablette<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code1 = '1')</span></td></tr></table></blockquote></div>"
        },
        "extension" : [
          {
            "url" : "http://gefyra.info/training/StructureDefinition/ExtensionISiKAcceptedRisk",
            "valueString" : "Erhöhtes Blutungsrisiko ist in diesem Fall vertretbar."
          },
          {
            "url" : "http://gefyra.info/training/StructureDefinition/ExtensionISiKMedikationsart",
            "valueCoding" : {
              "system" : "http://gefyra.info/training/CodeSystem/ISiKMedikationsartCS",
              "code" : "akut"
            }
          },
          {
            "url" : "http://gefyra.info/training/StructureDefinition/ExtensionISiKSelbstmedikation",
            "valueBoolean" : true
          },
          {
            "url" : "http://gefyra.info/training/StructureDefinition/ExtensionISiKBehandlungsziel",
            "valueString" : "Schmerztherapie postoperativ"
          }
        ],
        "status" : "active",
        "medicationReference" : {
          "reference" : "Medication/ExampleISiKMedikament1"
        },
        "subject" : {
          "reference" : "Patient/PatientinMusterfrau"
        },
        "context" : {
          "reference" : "Encounter/FachabteilungskontaktMinimal"
        },
        "effectivePeriod" : {
          "start" : "2021-07-01"
        },
        "dateAsserted" : "2021-07-01",
        "reasonReference" : [
          {
            "reference" : "Condition/BehandlungsDiagnoseFreitext"
          }
        ],
        "dosage" : [
          {
            "timing" : {
              "repeat" : {
                "when" : ["MORN", "NOON", "EVE"]
              }
            },
            "doseAndRate" : [
              {
                "doseQuantity" : {
                  "value" : 1,
                  "unit" : "Brausetablette",
                  "system" : "http://unitsofmeasure.org",
                  "code" : "1"
                }
              }
            ]
          }
        ]
      },
      "response" : {
        "status" : "201",
        "location" : "http://my.fhir.server.local/MedicationStatement/ExampleISiKMedikationsInformation1"
      }
    },
    {
      "fullUrl" : "http://my.target.fhir.server.local/Medication/ExampleISiKMedikament1",
      "resource" : {
        "resourceType" : "Medication",
        "id" : "ExampleISiKMedikament1",
        "meta" : {
          "profile" : [
            "http://gefyra.info/training/StructureDefinition/ISiKMedikament"
          ]
        },
        "text" : {
          "status" : "additional",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Medication_ExampleISiKMedikament1\"> </a>Medikament codiert (Wirkstoff)</div>"
        },
        "code" : {
          "coding" : [
            {
              "system" : "http://fhir.de/CodeSystem/bfarm/atc",
              "version" : "2024",
              "code" : "V03AB23",
              "display" : "Acetylcystein"
            }
          ]
        },
        "status" : "active"
      },
      "response" : {
        "status" : "201",
        "location" : "http://my.fhir.server.local/Medication/ExampleISiKMedikament1"
      }
    }
  ]
}

```

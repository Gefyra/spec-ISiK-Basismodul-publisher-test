# ObservationCodesPCT - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ObservationCodesPCT**

## ValueSet: ObservationCodesPCT 

| | |
| :--- | :--- |
| *Official URL*:http://gefyra.info/training/ValueSet/ObservationCodesPCT | *Version*:0.1.0 |
| Active as of 2025-10-23 | *Computable Name*:ObservationCodesPCT |

 
Enthält LOINC-Codes für die Observation PCT 

 **References** 

* [ISiKLaboruntersuchungPCT](StructureDefinition-ISiKLaboruntersuchungPCT.md)

### Logical Definition (CLD)

 

### Expansion

Expansion from tx.fhir.org based on Loinc v2.81

This value set contains 3 concepts

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "ObservationCodesPCT",
  "url" : "http://gefyra.info/training/ValueSet/ObservationCodesPCT",
  "version" : "0.1.0",
  "name" : "ObservationCodesPCT",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-10-23",
  "publisher" : "Gefyra GmbH",
  "contact" : [
    {
      "name" : "Gefyra GmbH",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://gefyra.info/"
        }
      ]
    }
  ],
  "description" : "Enthält LOINC-Codes für die Observation PCT",
  "compose" : {
    "include" : [
      {
        "system" : "http://loinc.org",
        "concept" : [
          {
            "code" : "33959-8",
            "display" : "Procalcitonin [Masse/Volumen] in Serum oder Plasma"
          },
          {
            "code" : "75241-0",
            "display" : "Procalcitonin [Masse/Volumen] in Serum oder Plasma mittels Immunoassay"
          },
          {
            "code" : "51637-7",
            "display" : "Thrombokrit [Volumenfraktion] in Blut"
          }
        ]
      }
    ]
  }
}

```

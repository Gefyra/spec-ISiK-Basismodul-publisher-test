# ExampleISiKLaboruntersuchungPCT1 - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ExampleISiKLaboruntersuchungPCT1**

## Example Observation: ExampleISiKLaboruntersuchungPCT1

Profile: [ISiKLaboruntersuchungPCT](StructureDefinition-ISiKLaboruntersuchungPCT.md)

**status**: Final

**category**: Laboratory

**code**: Procalcitonin

**subject**: [Erika Fürstin von Musterfrau (official) Female, DoB: 1964-08-12 ( Private Krankenversicherung (use: secondary, ))](Patient-PatientinMusterfrau.md)

**effective**: 2021-09-01 12:00:00+0000

**performer**: [Practitioner Walter Arzt(official)](Practitioner-PractitionerWalterArzt.md)

**value**: 0.2 ng/mL(Details: UCUM codeng/mL = 'ng/mL')

### ReferenceRanges

| | |
| :--- | :--- |
| - | **High** |
| * | 0.5 ng/mL(Details: UCUM codeng/mL = 'ng/mL') |



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "ExampleISiKLaboruntersuchungPCT1",
  "meta" : {
    "profile" : [
      "http://gefyra.info/training/StructureDefinition/ISiKLaboruntersuchungPCT"
    ]
  },
  "status" : "final",
  "category" : [
    {
      "coding" : [
        {
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }
      ]
    }
  ],
  "code" : {
    "coding" : [
      {
        "system" : "http://loinc.org",
        "code" : "33959-8"
      },
      {
        "system" : "http://snomed.info/sct",
        "code" : "418752001",
        "display" : "Procalcitonin"
      }
    ]
  },
  "subject" : {
    "reference" : "Patient/PatientinMusterfrau"
  },
  "effectiveDateTime" : "2021-09-01T12:00:00Z",
  "performer" : [
    {
      "reference" : "Practitioner/PractitionerWalterArzt"
    }
  ],
  "valueQuantity" : {
    "value" : 0.2,
    "system" : "http://unitsofmeasure.org",
    "code" : "ng/mL"
  },
  "referenceRange" : [
    {
      "high" : {
        "value" : 0.5,
        "system" : "http://unitsofmeasure.org",
        "code" : "ng/mL"
      }
    }
  ]
}

```

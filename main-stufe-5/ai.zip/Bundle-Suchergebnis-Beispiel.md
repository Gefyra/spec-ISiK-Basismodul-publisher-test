# Suchergebnis-Beispiel - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Suchergebnis-Beispiel**

## Example Bundle: Suchergebnis-Beispiel

Profile: [Suchergebnisse einer Dokumentensuche](StructureDefinition-ISiKDokumentenSuchergebnisse.md)

Bundle Suchergebnis-Beispiel of type searchset

-------

Entry 1 - fullUrl = http://meinfhirserver.de/DocumentReference/dok-beispiel-server

Resource DocumentReference:

> 

Profile: [Erforderliche Metadaten für Dokumentenaustausch in ISiK](StructureDefinition-ISiKDokumentenMetadaten.md)

Security Label: test health data (Details: ActReason code HTEST = 'test health data')

**identifier**:[Uniform Resource Identifier (URI)](http://terminology.hl7.org/6.5.0/NamingSystem-uri.html)/urn:oid:1.2.840.113556.1.8000.2554.58783.21864.3474.19410.44358.58254.41281.46340**status**: Current**type**:Molekularpathologiebefund**category**:Befundbericht**subject**:[Erika Fürstin von Musterfrau (official) Female, DoB: 1964-08-12 ( Private Krankenversicherung (use: secondary, ))](Patient-PatientinMusterfrau.md)
> **context**[Encounter: extension = ,2025-01-02,2025-01-04; identifier = Visit number; status = finished; class = inpatient encounter (ActCode#IMP); type = Abteilungskontakt,Operation; serviceType = Orthopädie; period = 2024-10-21 --> 2025-01-01](Encounter-FachabteilungskontaktNormal.md)
**securityLabel**:normal
> **content**

### Attachments

| | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- |
| - | **ContentType** | **Language** | **Url** | **Title** | **Creation** |
| * | application/pdf | de | [https://mein-Dokumentenserver/dokumente/1.2.840.113556.1.8000.2554.58783.21864.3474.19410.44358.58254.41281.46340.pdf](https://simplifier.net/resolve?scope=de.basisprofil.r4@1.5.4&canonical=https://mein-Dokumentenserver/dokumente/1.2.840.113556.1.8000.2554.58783.21864.3474.19410.44358.58254.41281.46340.pdf) | Molekularpathologiebefund vom 31.12.21 | 2020-12-31 23:50:50-0500 |





## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "Suchergebnis-Beispiel",
  "meta" : {
    "profile" : [
      "http://gefyra.info/training/StructureDefinition/ISiKDokumentenSuchergebnisse"
    ]
  },
  "type" : "searchset",
  "total" : 1,
  "link" : [
    {
      "relation" : "self",
      "url" : "http://meinfhirserver.de/DocumentReference?patient.identifier=A123456789"
    }
  ],
  "entry" : [
    {
      "fullUrl" : "http://meinfhirserver.de/DocumentReference/dok-beispiel-server",
      "resource" : {
        "resourceType" : "DocumentReference",
        "id" : "dok-beispiel-server",
        "meta" : {
          "profile" : [
            "http://gefyra.info/training/StructureDefinition/ISiKDokumentenMetadaten"
          ],
          "security" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
              "code" : "HTEST"
            }
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"DocumentReference_dok-beispiel-server\"> </a><p class=\"res-header-id\"><b>Generated Narrative: DocumentReference dok-beispiel-server</b></p><a name=\"dok-beispiel-server\"> </a><a name=\"hcdok-beispiel-server\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-ISiKDokumentenMetadaten.html\">Erforderliche Metadaten für Dokumentenaustausch in ISiK</a></p><p style=\"margin-bottom: 0px\">Security Label: test health data (Details: ActReason code HTEST = 'test health data')</p></div><p><b>masterIdentifier</b>: <a href=\"http://terminology.hl7.org/6.5.0/NamingSystem-uri.html\" title=\"As defined by RFC 3986 (http://www.ietf.org/rfc/rfc3986.txt)(with many schemes defined in many RFCs). For OIDs and UUIDs, use the URN form (urn:oid:(note: lowercase) and urn:uuid:). See http://www.ietf.org/rfc/rfc3001.txt and http://www.ietf.org/rfc/rfc4122.txt \r\n\r\nThis oid is used as an identifier II.root to indicate the the extension is an absolute URI (technically, an IRI). Typically, this is used for OIDs and GUIDs. Note that when this OID is used with OIDs and GUIDs, the II.extension should start with urn:oid or urn:uuid: \r\n\r\nNote that this OID is created to aid with interconversion between CDA and FHIR - FHIR uses urn:ietf:rfc:3986 as equivalent to this OID. URIs as identifiers appear more commonly in FHIR.\r\n\r\nThis OID may also be used in CD.codeSystem.\">Uniform Resource Identifier (URI)</a>/urn:oid:1.2.840.113556.1.8000.2554.58783.21864.3474.19410.44358.58254.41281.46340</p><p><b>status</b>: Current</p><p><b>type</b>: <span title=\"Codes:{http://dvmd.de/fhir/CodeSystem/kdl PT130102}, {http://ihe-d.de/CodeSystems/IHEXDStypeCode PATH}\">Molekularpathologiebefund</span></p><p><b>category</b>: <span title=\"Codes:{http://ihe-d.de/CodeSystems/IHEXDSclassCode BEF}\">Befundbericht</span></p><p><b>subject</b>: <a href=\"Patient-PatientinMusterfrau.html\">Erika Fürstin von Musterfrau (official) Female, DoB: 1964-08-12 ( Private Krankenversicherung (use: secondary, ))</a></p><p><b>securityLabel</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-Confidentiality N}\">normal</span></p><blockquote><p><b>content</b></p><h3>Attachments</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ContentType</b></td><td><b>Language</b></td><td><b>Url</b></td><td><b>Title</b></td><td><b>Creation</b></td></tr><tr><td style=\"display: none\">*</td><td>application/pdf</td><td>German</td><td><a href=\"https://simplifier.net/resolve?scope=de.basisprofil.r4@1.5.4&amp;canonical=https://mein-Dokumentenserver/dokumente/1.2.840.113556.1.8000.2554.58783.21864.3474.19410.44358.58254.41281.46340.pdf\">https://mein-Dokumentenserver/dokumente/1.2.840.113556.1.8000.2554.58783.21864.3474.19410.44358.58254.41281.46340.pdf</a></td><td>Molekularpathologiebefund vom 31.12.21</td><td>2020-12-31 23:50:50-0500</td></tr></table><p><b>format</b>: <a href=\"https://profiles.ihe.net/fhir/ihe.formatcode.fhir/1.4.0/CodeSystem-formatcode.html#formatcode-urn.58ihe.58iti.58xds.582017.58mimeTypeSufficient\">IHE Format Code set for use with Document Sharing: urn:ihe:iti:xds:2017:mimeTypeSufficient</a> (Format aus MIME Type ableitbar)</p></blockquote><h3>Contexts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Encounter</b></td><td><b>FacilityType</b></td><td><b>PracticeSetting</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Encounter-FachabteilungskontaktNormal.html\">Encounter: extension = ,2025-01-02,2025-01-04; identifier = Visit number; status = finished; class = inpatient encounter (ActCode#IMP); type = Abteilungskontakt,Operation; serviceType = Orthopädie; period = 2024-10-21 --&gt; 2025-01-01</a></td><td><span title=\"Codes:{http://ihe-d.de/CodeSystems/PatientBezogenenGesundheitsversorgung KHS}\">Krankenhaus</span></td><td><span title=\"Codes:{http://ihe-d.de/CodeSystems/AerztlicheFachrichtungen ALLG}\">Allgemeinmedizin</span></td></tr></table></div>"
        },
        "masterIdentifier" : {
          "system" : "urn:ietf:rfc:3986",
          "value" : "urn:oid:1.2.840.113556.1.8000.2554.58783.21864.3474.19410.44358.58254.41281.46340"
        },
        "status" : "current",
        "type" : {
          "coding" : [
            {
              "system" : "http://dvmd.de/fhir/CodeSystem/kdl",
              "code" : "PT130102",
              "display" : "Molekularpathologiebefund"
            },
            {
              "system" : "http://ihe-d.de/CodeSystems/IHEXDStypeCode",
              "code" : "PATH",
              "display" : "Pathologiebefundberichte"
            }
          ]
        },
        "category" : [
          {
            "coding" : [
              {
                "system" : "http://ihe-d.de/CodeSystems/IHEXDSclassCode",
                "code" : "BEF",
                "display" : "Befundbericht"
              }
            ]
          }
        ],
        "subject" : {
          "reference" : "Patient/PatientinMusterfrau"
        },
        "securityLabel" : [
          {
            "coding" : [
              {
                "system" : "http://terminology.hl7.org/CodeSystem/v3-Confidentiality",
                "code" : "N"
              }
            ]
          }
        ],
        "content" : [
          {
            "attachment" : {
              "contentType" : "application/pdf",
              "language" : "de",
              "url" : "https://mein-Dokumentenserver/dokumente/1.2.840.113556.1.8000.2554.58783.21864.3474.19410.44358.58254.41281.46340.pdf",
              "title" : "Molekularpathologiebefund vom 31.12.21",
              "creation" : "2020-12-31T23:50:50-05:00"
            },
            "format" : {
              "system" : "http://ihe.net/fhir/ihe.formatcode.fhir/CodeSystem/formatcode",
              "code" : "urn:ihe:iti:xds:2017:mimeTypeSufficient",
              "display" : "Format aus MIME Type ableitbar"
            }
          }
        ],
        "context" : {
          "encounter" : [
            {
              "reference" : "Encounter/FachabteilungskontaktNormal"
            }
          ],
          "facilityType" : {
            "coding" : [
              {
                "system" : "http://ihe-d.de/CodeSystems/PatientBezogenenGesundheitsversorgung",
                "code" : "KHS",
                "display" : "Krankenhaus"
              }
            ]
          },
          "practiceSetting" : {
            "coding" : [
              {
                "system" : "http://ihe-d.de/CodeSystems/AerztlicheFachrichtungen",
                "code" : "ALLG"
              }
            ]
          }
        }
      }
    }
  ]
}

```

# Home - v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://gefyra.info/training/ImplementationGuide/info.gefyra.training | *Version*:0.1.0 |
| Active as of 2025-11-18 | *Computable Name*:SchulungsIG |

# ISiK IG Publisher Test

Feel free to modify this index page with your own awesome content!


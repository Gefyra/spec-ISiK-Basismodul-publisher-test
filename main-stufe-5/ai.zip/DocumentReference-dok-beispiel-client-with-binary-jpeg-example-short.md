# dok-beispiel - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **dok-beispiel**

## Example DocumentReference: dok-beispiel

Profile: [Erforderliche Metadaten für Dokumentenaustausch in ISiK](StructureDefinition-ISiKDokumentenMetadaten.md)

Security Label: test health data (Details: ActReason code HTEST = 'test health data')

**masterIdentifier**: [Uniform Resource Identifier (URI)](http://terminology.hl7.org/6.5.0/NamingSystem-uri.html)/urn:oid:1.2.840.113556.1.8000.2554.58783.21864.3474.19410.44358.58254.41281.46340

**status**: Current

**type**: Fotodokumentation Operation

**subject**: [Erika Fürstin von Musterfrau (official) Female, DoB: 1964-08-12 ( Private Krankenversicherung (use: secondary, ))](Patient-PatientinMusterfrau.md)

**securityLabel**: normal

> **content**

### Attachments

| | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- |
| - | **ContentType** | **Language** | **Data** | **Title** | **Creation** |
| * | image/jpeg | German | `4AAQSkZJRgABAQEB` | Fotodokumentation Operation vom 31.12.21 | 2020-12-31 23:50:50-0500 |

**format**:[IHE Format Code set for use with Document Sharing: urn:ihe:iti:xds:2017:mimeTypeSufficient](https://profiles.ihe.net/fhir/ihe.formatcode.fhir/1.4.0/CodeSystem-formatcode.html#formatcode-urn.58ihe.58iti.58xds.582017.58mimeTypeSufficient)(Format aus MIME Type ableitbar)

### Contexts

| | | | |
| :--- | :--- | :--- | :--- |
| - | **Encounter** | **FacilityType** | **PracticeSetting** |
| * | [Encounter: extension = ,2025-01-02,2025-01-04; identifier = Visit number; status = finished; class = inpatient encounter (ActCode#IMP); type = Abteilungskontakt,Operation; serviceType = Orthopädie; period = 2024-10-21 --> 2025-01-01](Encounter-FachabteilungskontaktNormal.md) | Krankenhaus | Allgemeinmedizin |



## Resource Content

```json
{
  "resourceType" : "DocumentReference",
  "id" : "dok-beispiel-client-with-binary-jpeg-example-short",
  "meta" : {
    "profile" : [
      "http://gefyra.info/training/StructureDefinition/ISiKDokumentenMetadaten"
    ],
    "security" : [
      {
        "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
        "code" : "HTEST"
      }
    ]
  },
  "masterIdentifier" : {
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:1.2.840.113556.1.8000.2554.58783.21864.3474.19410.44358.58254.41281.46340"
  },
  "status" : "current",
  "type" : {
    "coding" : [
      {
        "system" : "http://dvmd.de/fhir/CodeSystem/kdl",
        "code" : "ED020101",
        "display" : "Fotodokumentation Operation"
      }
    ]
  },
  "subject" : {
    "reference" : "Patient/PatientinMusterfrau"
  },
  "securityLabel" : [
    {
      "coding" : [
        {
          "system" : "http://terminology.hl7.org/CodeSystem/v3-Confidentiality",
          "code" : "N"
        }
      ]
    }
  ],
  "content" : [
    {
      "attachment" : {
        "contentType" : "image/jpeg",
        "language" : "de",
        "data" : "4AAQSkZJRgABAQEB",
        "title" : "Fotodokumentation Operation vom 31.12.21",
        "creation" : "2020-12-31T23:50:50-05:00"
      },
      "format" : {
        "system" : "http://ihe.net/fhir/ihe.formatcode.fhir/CodeSystem/formatcode",
        "code" : "urn:ihe:iti:xds:2017:mimeTypeSufficient",
        "display" : "Format aus MIME Type ableitbar"
      }
    }
  ],
  "context" : {
    "encounter" : [
      {
        "reference" : "Encounter/FachabteilungskontaktNormal"
      }
    ],
    "facilityType" : {
      "coding" : [
        {
          "system" : "http://ihe-d.de/CodeSystems/PatientBezogenenGesundheitsversorgung",
          "code" : "KHS",
          "display" : "Krankenhaus"
        }
      ]
    },
    "practiceSetting" : {
      "coding" : [
        {
          "system" : "http://ihe-d.de/CodeSystems/AerztlicheFachrichtungen",
          "code" : "ALLG"
        }
      ]
    }
  }
}

```

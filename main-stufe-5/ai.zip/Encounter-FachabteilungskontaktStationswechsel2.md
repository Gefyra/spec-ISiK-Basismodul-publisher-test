# FachabteilungskontaktStationswechsel2 - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FachabteilungskontaktStationswechsel2**

## Example Encounter: FachabteilungskontaktStationswechsel2

Profile: [ISiKKontaktGesundheitseinrichtung](StructureDefinition-ISiKKontaktGesundheitseinrichtung.md)

**identifier**: Visit number/0123456789

**status**: In Progress

**class**: [ActCode: IMP](http://terminology.hl7.org/7.0.0/CodeSystem-v3-ActCode.html#v3-ActCode-IMP) (inpatient encounter)

**type**: Abteilungskontakt

**serviceType**: Innere Medizin

**subject**: [Anna Müller (official) Female, DoB: 1957-08-12 ( Krankenversichertennummer)](Patient-PatientinNormal.md)

**period**: 2025-01-15 14:00:00+0100 --> (ongoing)

> **location****location**: Station INNG1 (Identifier:`https://test.krankenhaus.de/fhir/sid/stationId`/INNG1)**status**: Active**physicalType**:Ward

> **location****location**: Zimmer Z001 (Identifier:`https://test.krankenhaus.de/fhir/sid/zimmerId`/Z001)**status**: Active**physicalType**:Room

> **location****location**: Bett A010 (Identifier:`https://test.krankenhaus.de/fhir/sid/bettId`/A010)**status**: Active**physicalType**:Bed



## Resource Content

```json
{
  "resourceType" : "Encounter",
  "id" : "FachabteilungskontaktStationswechsel2",
  "meta" : {
    "profile" : [
      "http://gefyra.info/training/StructureDefinition/ISiKKontaktGesundheitseinrichtung"
    ]
  },
  "identifier" : [
    {
      "type" : {
        "coding" : [
          {
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "VN"
          }
        ]
      },
      "value" : "0123456789"
    }
  ],
  "status" : "in-progress",
  "class" : {
    "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
    "code" : "IMP"
  },
  "type" : [
    {
      "coding" : [
        {
          "system" : "http://fhir.de/CodeSystem/Kontaktebene",
          "code" : "abteilungskontakt"
        }
      ]
    }
  ],
  "serviceType" : {
    "coding" : [
      {
        "system" : "http://fhir.de/CodeSystem/dkgev/Fachabteilungsschluessel",
        "code" : "0100",
        "display" : "Innere Medizin"
      }
    ]
  },
  "subject" : {
    "reference" : "Patient/PatientinNormal"
  },
  "period" : {
    "start" : "2025-01-15T14:00:00+01:00"
  },
  "location" : [
    {
      "location" : {
        "identifier" : {
          "system" : "https://test.krankenhaus.de/fhir/sid/stationId",
          "value" : "INNG1"
        },
        "display" : "Station INNG1"
      },
      "status" : "active",
      "physicalType" : {
        "coding" : [
          {
            "system" : "http://terminology.hl7.org/CodeSystem/location-physical-type",
            "code" : "wa",
            "display" : "Ward"
          }
        ]
      }
    },
    {
      "location" : {
        "identifier" : {
          "system" : "https://test.krankenhaus.de/fhir/sid/zimmerId",
          "value" : "Z001"
        },
        "display" : "Zimmer Z001"
      },
      "status" : "active",
      "physicalType" : {
        "coding" : [
          {
            "system" : "http://terminology.hl7.org/CodeSystem/location-physical-type",
            "code" : "ro",
            "display" : "Room"
          }
        ]
      }
    },
    {
      "location" : {
        "identifier" : {
          "system" : "https://test.krankenhaus.de/fhir/sid/bettId",
          "value" : "A010"
        },
        "display" : "Bett A010"
      },
      "status" : "active",
      "physicalType" : {
        "coding" : [
          {
            "system" : "http://terminology.hl7.org/CodeSystem/location-physical-type",
            "code" : "bd",
            "display" : "Bed"
          }
        ]
      }
    }
  ]
}

```
